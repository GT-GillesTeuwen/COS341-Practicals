package Nodes.ReductionStrategies;

import Nodes.nNode;

public class NodeReductionStrategy {
    public void handle(nNode node) {
    }
}
