package Exceptions;

public class AmbiguousDeclarationException extends Exception {
    public AmbiguousDeclarationException(String errorMessage) {
        super(errorMessage);
    }
}
