package Exceptions;

public class ProcedureNotDeclaredException extends Exception {
    public ProcedureNotDeclaredException(String errorMessage) {
        super(errorMessage);
    }
}
