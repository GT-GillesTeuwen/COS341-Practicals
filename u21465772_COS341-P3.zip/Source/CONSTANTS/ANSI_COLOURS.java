package CONSTANTS;

public class ANSI_COLOURS {
    public static final String ANSI_Black = "\u001b[30m";
    public static final String ANSI_Red = "\u001b[31m";
    public static final String ANSI_Green = "\u001b[32m";
    public static final String ANSI_Yellow = "\u001b[33m";
    public static final String ANSI_Blue = "\u001b[34m";
    public static final String ANSI_Magenta = "\u001b[35m";
    public static final String ANSI_Cyan = "\u001b[36m";
    public static final String ANSI_White = "\u001b[37m";
    public static final String ANSI_Reset = "\u001b[0m";
}
