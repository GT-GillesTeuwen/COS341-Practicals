package Nodes.Strategies;

import Nodes.nNode;

public class NodeReductionStrategy {
    public void handle(nNode node) {
    }
}
