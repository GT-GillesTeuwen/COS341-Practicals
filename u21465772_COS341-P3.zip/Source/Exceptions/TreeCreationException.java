package Exceptions;

public class TreeCreationException extends Exception {
    public TreeCreationException(String errorMessage) {
        super(errorMessage);
    }
}
