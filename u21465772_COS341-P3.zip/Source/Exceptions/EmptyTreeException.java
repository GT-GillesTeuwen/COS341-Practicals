package Exceptions;

public class EmptyTreeException extends Exception {
    public EmptyTreeException(String errorMessage) {
        super(errorMessage);
    }
}
