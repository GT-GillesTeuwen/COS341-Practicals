public abstract class AbstractExpression {
  public abstract NFA interpret();
}